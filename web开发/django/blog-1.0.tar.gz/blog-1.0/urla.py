#!/usr/bin/env python
# -*- coding: utf-8 -*-
# File  : urla.py
# Author: HuXianyong
# Date  : 2019/7/24 16:19


from urllib.request import urlopen

url = 'http://www.bing.com'

response = urlopen(url)
print(response,type(response).mro())
print(response.__dict__)